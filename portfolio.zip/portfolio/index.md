---
layout: default
title: Bienvenue
---

# Bienvenue sur mon Portfolio !

Je suis Grom-P, freelance en analyse de données et assistance informatique.

## Mes Services
- **Analyse de données** : Nettoyage, structuration, création de tableaux de bord.
- **Assistance informatique** : Résolution de problèmes, configuration de réseaux.
- **Missions ponctuelles** : Tableaux automatisés, conseils d'optimisation.

## Contactez-moi
Vous pouvez me joindre à : [votremail@example.com](mailto:votremail@example.com).
